import React from 'react';
import Header from './components/Header';
import ObjectDetection from './components/ObjectDetection';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="w-full max-w-7xl flex-grow flex flex-col items-center justify-center">
        <ObjectDetection />
      </main>
      <footer className="w-full text-center p-4 text-xs text-gray-500 mt-8">
        <p>Powered by React, Tailwind CSS, and Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;
