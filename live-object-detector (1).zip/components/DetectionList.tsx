import React from 'react';
import { DetectedObject } from '../types';

interface DetectionListProps {
  objects: DetectedObject[];
}

const DetectionList: React.FC<DetectionListProps> = ({ objects }) => {
  return (
    <div className="w-full lg:w-1/3 bg-gray-900/50 border border-gray-700 rounded-lg p-4 flex flex-col">
      <h2 className="text-xl font-bold mb-4 text-cyan-400 flex-shrink-0">Detected Objects</h2>
      <div className="flex-grow overflow-y-auto pr-2 -mr-2">
        {objects.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-400 text-center">No objects detected yet. Point your camera at something!</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {objects.map((obj, index) => (
              <li 
                key={`${obj.label}-${index}`} 
                className="flex justify-between items-center bg-gray-800 p-3 rounded-md shadow-sm"
              >
                <span className="font-medium text-white capitalize">{obj.label}</span>
                <span className="text-sm font-mono bg-cyan-900/50 text-cyan-300 px-2 py-1 rounded-full">
                  {(obj.confidence * 100).toFixed(1)}%
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default DetectionList;
