
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-5xl mb-6 text-center">
        <div className="flex items-center justify-center gap-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 10l-2.5 2.5M10 10l2.5 2.5M10 10l2.5-2.5M10 10l-2.5-2.5" />
            </svg>
            <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                Live Object Detector
            </h1>
        </div>
      <p className="mt-3 text-lg text-gray-400">Real-time object identification through your camera with Gemini</p>
    </header>
  );
};

export default Header;
