import React, { useState, useRef, useCallback, useEffect } from 'react';
import { detectObjects } from '../services/geminiService';
import { DetectedObject } from '../types';
import Loader from './Loader';
import ErrorDisplay from './ErrorDisplay';
import DetectionList from './DetectionList';

const DETECTION_INTERVAL_MS = 1000; // 1 detection per second
const VIDEO_WIDTH = 640;
const VIDEO_HEIGHT = 480;

const ObjectDetection: React.FC = () => {
  const [isDetecting, setIsDetecting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [detectedObjects, setDetectedObjects] = useState<DetectedObject[]>([]);
  const [isCameraOn, setIsCameraOn] = useState<boolean>(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const stopCamera = useCallback(() => {
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
      detectionIntervalRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraOn(false);
    setDetectedObjects([]);
  }, []);

  const startDetectionLoop = useCallback(() => {
    detectionIntervalRef.current = setInterval(async () => {
      if (isDetecting || !videoRef.current || videoRef.current.paused || videoRef.current.ended) {
        return;
      }

      const video = videoRef.current;
      if (video.readyState < 2 || video.videoWidth === 0) return;

      setIsDetecting(true);
      
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = video.videoWidth;
      tempCanvas.height = video.videoHeight;
      const ctx = tempCanvas.getContext('2d');
      if (!ctx) {
        setIsDetecting(false);
        return;
      }

      // Flip the captured image horizontally to match the user's mirrored view
      ctx.scale(-1, 1);
      ctx.translate(-tempCanvas.width, 0);
      ctx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height);
      const dataUrl = tempCanvas.toDataURL('image/jpeg', 0.8);
      const base64Image = dataUrl.split(',')[1];
      
      try {
        const objects = await detectObjects(base64Image);
        setDetectedObjects(objects);
      } catch (err) {
        setError("Failed to detect objects. Please try again.");
        console.error(err);
      } finally {
        setIsDetecting(false);
      }
    }, DETECTION_INTERVAL_MS);
  }, [isDetecting]);

  const startCamera = async () => {
    setError(null);
    setDetectedObjects([]);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: VIDEO_WIDTH },
            height: { ideal: VIDEO_HEIGHT }
          } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setIsCameraOn(true);
          startDetectionLoop();
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
        setError("Camera access was denied. Please allow camera permissions in your browser settings to use this feature.");
      }
    } else {
      setError("Your browser does not support camera access (getUserMedia).");
    }
  };

  const drawBoundingBoxes = useCallback(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || video.videoWidth === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = video.clientWidth;
    canvas.height = video.clientHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const scaleX = canvas.width / video.videoWidth;
    const scaleY = canvas.height / video.videoHeight;

    detectedObjects.forEach(obj => {
      const { x, y, width, height } = obj.box;
      const scaledX = x * scaleX;
      const scaledY = y * scaleY;
      const scaledWidth = width * scaleX;
      const scaledHeight = height * scaleY;

      // Draw bounding box
      ctx.strokeStyle = '#06b6d4'; // cyan-500
      ctx.lineWidth = 3;
      ctx.strokeRect(scaledX, scaledY, scaledWidth, scaledHeight);

      // Draw label background
      const label = `${obj.label} (${(obj.confidence * 100).toFixed(1)}%)`;
      ctx.font = '14px sans-serif';
      const textWidth = ctx.measureText(label).width;
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(scaledX, scaledY - 20, textWidth + 8, 20);

      // Draw label text
      ctx.fillStyle = '#ffffff';
      ctx.fillText(label, scaledX + 4, scaledY - 6);
    });
  }, [detectedObjects]);
  
  useEffect(() => {
    if (isCameraOn) {
      drawBoundingBoxes();
    }
  }, [detectedObjects, isCameraOn, drawBoundingBoxes]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return (
    <div className="w-full flex flex-col lg:flex-row items-stretch gap-6 bg-gray-800 p-4 rounded-xl shadow-2xl border border-gray-700">
      {/* Left Column: Video and Controls */}
      <div className="w-full lg:w-2/3 flex flex-col items-center gap-4">
        <div className="relative w-full aspect-[4/3] max-w-full overflow-hidden rounded-lg bg-black flex items-center justify-center">
          <video
            ref={videoRef}
            className="w-full h-full object-contain"
            playsInline
            muted
            style={{ transform: 'scaleX(-1)' }} // Mirror view
          />
          <canvas 
              ref={canvasRef} 
              className="absolute top-0 left-0 w-full h-full pointer-events-none" 
          />
          {!isCameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              <p>Camera is off</p>
            </div>
          )}
          {isDetecting && (
            <div className="absolute bottom-4 right-4">
                <Loader />
            </div>
          )}
        </div>

        {error && <ErrorDisplay message={error} />}

        <div className="flex space-x-4">
          {!isCameraOn ? (
            <button
              onClick={startCamera}
              className="px-6 py-3 bg-cyan-500 text-white font-semibold rounded-lg shadow-md hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transition-transform transform hover:scale-105"
            >
              Start Camera
            </button>
          ) : (
            <button
              onClick={stopCamera}
              className="px-6 py-3 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transition-transform transform hover:scale-105"
            >
              Stop Camera
            </button>
          )}
        </div>
      </div>
      
      {/* Right Column: Detections List */}
      <DetectionList objects={detectedObjects} />
    </div>
  );
};

export default ObjectDetection;