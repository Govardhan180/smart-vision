
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { DetectedObject } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const objectDetectionSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      label: {
        type: Type.STRING,
        description: "A descriptive label for the detected object (e.g., 'cat', 'laptop').",
      },
      confidence: {
        type: Type.NUMBER,
        description: "The confidence score of the detection, from 0.0 to 1.0.",
      },
      box: {
        type: Type.OBJECT,
        properties: {
          x: {
            type: Type.NUMBER,
            description: "The x-coordinate of the top-left corner of the bounding box, in pixels.",
          },
          y: {
            type: Type.NUMBER,
            description: "The y-coordinate of the top-left corner of the bounding box, in pixels.",
          },
          width: {
            type: Type.NUMBER,
            description: "The width of the bounding box, in pixels.",
          },
          height: {
            type: Type.NUMBER,
            description: "The height of the bounding box, in pixels.",
          },
        },
        required: ["x", "y", "width", "height"],
      },
    },
    required: ["label", "confidence", "box"],
  },
};

export const detectObjects = async (base64Image: string): Promise<DetectedObject[]> => {
  try {
    const imagePart = {
      inlineData: {
        mimeType: 'image/jpeg',
        data: base64Image,
      },
    };

    const textPart = {
      text: "Analyze this image to detect all prominent objects. For each object, provide its label, a confidence score, and its bounding box in pixels. Only return objects with a confidence score above 0.3. If no objects are confidently detected, return an empty array.",
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: objectDetectionSchema,
      }
    });
    
    const jsonText = response.text.trim();
    if (!jsonText) {
        return [];
    }
    
    const detectedData = JSON.parse(jsonText);
    return detectedData as DetectedObject[];
  } catch (error) {
    console.error("Error detecting objects:", error);
    // In case of error (e.g., parsing, API call failed), return an empty array
    return [];
  }
};
